import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import clases.ParImpar;


class ParImparTest 
{

	@Test
	void parImparTest() 
	{
		ParImpar parimp = new ParImpar();
		
		boolean expected 	= true;
		boolean actual 		= parimp.parImpar();
		assertEquals(expected, actual);
	}

}
