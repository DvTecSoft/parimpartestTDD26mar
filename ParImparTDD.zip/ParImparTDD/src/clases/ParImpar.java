package clases;

public class ParImpar 
{
	/* ================================================
	 * Atributos
	 * ================================================
	 */

	int num1 		= 6;
	int num2 		= 2;
	double resto 	= 0;
	/* ================================================
	 * FIN Atributos
	 * ================================================
	 */

	
	/* ================================================
	 * Constructores
	 * ================================================
	 */

	/**
	 * 
	 */
	public ParImpar() 
	{
	}

	/**
	 * @param num1
	 * @param num2
	 * @param resto
	 */
	public ParImpar(int num1, int num2, double resto) 
	{
		this.num1 = num1;
		this.num2 = num2;
		this.resto = resto;
	}
	/* ================================================
	 * FIN Constructores
	 * ================================================
	 */


	/* ================================================
	 * Get & Set
	 * ================================================
	 */

	/**
	 * @return the num1
	 */
	public int getNum1() {
		return num1;
	}

	/**
	 * @param num1 the num1 to set
	 */
	public void setNum1(int num1) {
		this.num1 = num1;
	}

	/**
	 * @return the num2
	 */
	public int getNum2() {
		return num2;
	}

	/**
	 * @param num2 the num2 to set
	 */
	public void setNum2(int num2) {
		this.num2 = num2;
	}

	/**
	 * @return the resto
	 */
	public double getResto() {
		return resto;
	}

	/**
	 * @param resto the resto to set
	 */
	public void setResto(double resto) {
		this.resto = resto;
	}
	/* ================================================
	 * FIN Get & Set
	 * ================================================
	 */
	

	
	/* ================================================
	 * Métodos propios
	 * ================================================
	 */
	
	/**
	 * Método que retorna si es par o imprar con valor booleano
	 * @return
	 */
	public boolean parImpar()
	{
		this.resto = this.num1 % this.num2;
		if (this.resto == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/* ================================================
	 * FIN Métodos propios
	 * ================================================
	 */

	
	

}
